package org.jmattr.core.eventbus.tests;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jmattr.core.events.api.Event;
import org.jmattr.core.events.api.EventBus;
import org.jmattr.core.events.impl.RxEventBus;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import rx.observers.TestSubscriber;

public class EventBusTests {
	
	private EventBus eventBus = new RxEventBus("bus-1");

	@Before
	public void setUp() throws Exception {
		
		//eventBus.topic("channel").subscribe(event->{System.out.println("Received Event "+event);});
		
		eventBus.subscribe("channel",event->{System.out.println("Received Event "+event);});
		
			

	}

	@After
	public void tearDown() throws Exception {
		
		eventBus.unSubscribeAll();
	}

	@Test
	public void test_event_subscription_single_topic_single() {
		
		TestConsumer<Object> consumer = new TestConsumer<Object>();
		
		Event evt = new Event("Test",new HashMap());		
		
		eventBus.subscribe("channel",consumer);
		
		eventBus.publish("channel",evt);
		
		List events = consumer.getAccepted();
		
		assertTrue("No useful events received",events.size() > 0);
	}
	
	@Test
	public void test_event_subscription_multiple_topic_single(){

		TestConsumer<Object> consumer1 = new TestConsumer<Object>();
		TestConsumer<Object> consumer2 = new TestConsumer<Object>();
		TestConsumer<Object> consumer3 = new TestConsumer<Object>();
		TestConsumer<Object> consumer4 = new TestConsumer<Object>();
		
		Event evt = new Event("Test",new HashMap());		
		
		eventBus.subscribe("channel",consumer1);
		eventBus.subscribe("channel",consumer2);
		eventBus.subscribe("channel",consumer3);
		eventBus.subscribe("channel",consumer4);
		
		eventBus.publish("channel",evt);
		
		List events1 = consumer1.getAccepted();
		List events2 = consumer2.getAccepted();
		List events3 = consumer3.getAccepted();
		List events4 = consumer4.getAccepted();
		
		
		assertTrue("1 : No useful events received",events1.size() > 0);
		assertTrue("2 : No useful events received",events2.size() > 0);
		assertTrue("3 : No useful events received",events3.size() > 0);
		assertTrue("4 : No useful events received",events4.size() > 0);
		
	}
	
	
	@Test
	public void test_event_subscription_multiple_topic_multiple(){
		TestConsumer<Object> consumer1 = new TestConsumer<Object>();
		TestConsumer<Object> consumer2 = new TestConsumer<Object>();
		TestConsumer<Object> consumer3 = new TestConsumer<Object>();
		TestConsumer<Object> consumer4 = new TestConsumer<Object>();
		
		Event evt = new Event("Test",new HashMap());		
		
		eventBus.subscribe("channel1",consumer1);
		eventBus.subscribe("channel2",consumer2);
		eventBus.subscribe("channel3",consumer3);
		eventBus.subscribe("channel4",consumer4);
		
		eventBus.publish("channel1",evt);
		eventBus.publish("channel2",evt);
		eventBus.publish("channel3",evt);
		eventBus.publish("channel4",evt);
		
		List events1 = consumer1.getAccepted();
		List events2 = consumer2.getAccepted();
		List events3 = consumer3.getAccepted();
		List events4 = consumer4.getAccepted();
		
		
		assertTrue("1 : No useful events received",events1.size() > 0);
		assertTrue("2 : No useful events received",events2.size() > 0);
		assertTrue("3 : No useful events received",events3.size() > 0);
		assertTrue("4 : No useful events received",events4.size() > 0);
		
	}
	
	
	@Test
	public void test_event_subscription_single_topic_single_events_multiple() {
		
		TestConsumer<Object> consumer = new TestConsumer<Object>();
		
		Event evt1 = new Event("Test1",new HashMap());		
		Event evt2 = new Event("Test2",new HashMap());
		Event evt3 = new Event("Test3",new HashMap());
		
		eventBus.subscribe("channel",consumer);
		
		eventBus.publish("channel",evt1);
		eventBus.publish("channel",evt2);
		eventBus.publish("channel",evt3);
		
		List events = consumer.getAccepted();
		
		assertTrue("Some events were not received",events.size() == 3);
	}
	

	@Test
	public void test_event_subscription_multiple_topic_multiple_events_multiple(){
		TestConsumer<Object> consumer1 = new TestConsumer<Object>();
		TestConsumer<Object> consumer2 = new TestConsumer<Object>();
		TestConsumer<Object> consumer3 = new TestConsumer<Object>();
		TestConsumer<Object> consumer4 = new TestConsumer<Object>();
		TestConsumer<Object> consumer5 = new TestConsumer<Object>();
		
		Event evt1 = new Event("Test1",new HashMap());		
		Event evt2 = new Event("Test2",new HashMap());
		Event evt3 = new Event("Test3",new HashMap());
		
		eventBus.subscribe("channel1",consumer1);
		eventBus.subscribe("channel2",consumer2);
		eventBus.subscribe("channel3",consumer3);
		eventBus.subscribe("channel4",consumer4);
		eventBus.subscribe("channel5",consumer5);
		
		eventBus.publish("channel1",evt1);
		eventBus.publish("channel1",evt2);
		
		eventBus.publish("channel2",evt2);
		eventBus.publish("channel2",evt3);
		
		eventBus.publish("channel3",evt2);
		eventBus.publish("channel3",evt3);

		eventBus.publish("channel4",evt3);
		
		List events1 = consumer1.getAccepted();
		List events2 = consumer2.getAccepted();
		List events3 = consumer3.getAccepted();
		List events4 = consumer4.getAccepted();
		List events5 = consumer5.getAccepted();
		
		assertTrue("1 : Some events were not received",events1.size() == 2);
		assertTrue("2 : Some events were not received",events2.size() == 2);
		assertTrue("3 : Some events were not received",events3.size() == 2);
		assertTrue("4 : Some events were not received",events4.size() == 1);
		assertTrue("5 : Some events were received",events5.size() == 0);
		
	}

	@Test
	public void test_event_subscription_single_topic_single_synchronous() {
		
		TestThreadedConsumer<Object> consumer = new TestThreadedConsumer<Object>();
		
		Event evt = new Event("Test",new HashMap());		
		
		eventBus.subscribe("channel",consumer);
		
		eventBus.publish("channel",evt);
		
		List events = consumer.getAccepted();
		
		Map<String,List<Object>> eventMap = consumer.getEventMap();
		
		assertTrue("No useful events received",events.size() == 1);
		
		eventMap.keySet().forEach(threadName -> {assertTrue(String.format("Event was received asynchronous creation : %s, received : %s", consumer.getCreationThread(),threadName),threadName.equals(consumer.getCreationThread()));});
		
	}

	@Test
	public void test_event_subscription_single_topic_single_asynchronous() throws InterruptedException {
		
		TestThreadedConsumer<Object> consumer = new TestThreadedConsumer<Object>();
		
		Event evt = new Event("TestAsync",new HashMap());		
		
		eventBus.subscribe("channel",EventBus.DeliveryMode.ASYNC,consumer);
		
		eventBus.publish("channel",evt);
		
	
		Thread.sleep(100);
		
		List events = consumer.getAccepted();
		
		Map<String,List<Object>> eventMap = consumer.getEventMap();
		
		assertTrue("No useful events received",events.size() == 1);
		
		eventMap.keySet().forEach(threadName -> {assertFalse(String.format("Event was received synchronous creation : %s, received : %s", consumer.getCreationThread(),threadName),threadName.equals(consumer.getCreationThread()));});
		
	}
	
}
