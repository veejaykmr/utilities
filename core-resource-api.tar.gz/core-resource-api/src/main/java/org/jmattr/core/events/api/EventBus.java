package org.jmattr.core.events.api;

import java.util.function.Consumer;

import org.jmattr.core.eventbus.tests.TestThreadedConsumer;
import org.jmattr.core.events.api.EventBus.DeliveryMode;


public interface EventBus {
	
	public enum DeliveryMode{
		SYNC,
		ASYNC
	}


	EventBus unSubscribeAll();

	EventBus subscribe(String string, Consumer<Object> consumer);

	EventBus publish(String string, Event evt);

	EventBus subscribe(String string, DeliveryMode async, Consumer<Object> consumer);

	
	

	

}
