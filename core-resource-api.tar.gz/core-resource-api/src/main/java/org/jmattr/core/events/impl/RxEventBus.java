package org.jmattr.core.events.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import org.jmattr.core.events.api.Event;
import org.jmattr.core.events.api.EventBus;

import rx.Observable;
import rx.observers.SerializedSubscriber;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import rx.subjects.SerializedSubject;
import rx.subjects.Subject;

public class RxEventBus implements EventBus {

	private String eventBus;
	
	private Map<String,Subject<Object,Object>> topics = new ConcurrentHashMap<String,Subject<Object,Object>>();
	
	private final String DEAD_TOPIC = "internal.dead";
	
	public RxEventBus(String name) {
		eventBus = name;
	}

	@Override
	public EventBus unSubscribeAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EventBus subscribe(String topicName, Consumer<Object> consumer) {
		return this.subscribe(topicName, DeliveryMode.SYNC, consumer);
	}
	
	

	private Subject defineTopic(String topicName) {
		Subject<Object,Object> newTopic = new SerializedSubject<>(PublishSubject.create());
		topics.put(topicName, newTopic);
		return newTopic;
	}

	private Subject getTopic(String topicName) {
		return topics.get(topicName);
	}

	private boolean isTopicDefined(String topicName) {
		return topics.containsKey(topicName);
	}

	@Override
	public EventBus publish(String topicName, Event evt) {
		Subject topic = null;
		
		if(isTopicDefined(topicName)){
			
			topic = getTopic(topicName);
		}else{
			//define new topic
			topic = getDefaultTopic();
		}

		topic.onNext(evt);
	
		
		return this;
	}

	private Subject getDefaultTopic() {
		
		if(!isTopicDefined(DEAD_TOPIC)){
			return defineTopic(DEAD_TOPIC);
		}
		return getTopic(DEAD_TOPIC);
	}

	@Override
	public EventBus subscribe(String topicName, DeliveryMode async, Consumer<Object> consumer) {
		Subject topic = null;
		
		if(isTopicDefined(topicName)){
			
			topic = getTopic(topicName);
		}else{
			//define new topic
			topic = defineTopic(topicName);
		}

		Observable topicObservable = topic;
		
		if(DeliveryMode.ASYNC == async){
			topicObservable = topic.observeOn(Schedulers.io()).subscribeOn(Schedulers.io());
		}

		topicObservable.subscribe(event -> {consumer.accept(event);});
		
		return this;
	}
	
	

}
